// === Глобальные переменные (вне всех функций, вверху файла) ===
bool drawEnabled = false;
bool espEnabled = false;
bool boxEnabled = false;
bool healthBarEnabled = false;
bool weaponEnabled = false;
bool nickEnabled = false;
float drawSize = 5.0f;
ImVec4 drawColor = ImVec4(1.0f, 0.0f, 0.0f, 1.0f); // Красный круг
void BeginDraw() {
    ImGuiIO &io = ImGui::GetIO();
    ImVec2 center = ImGui::GetMainViewport()->GetCenter();
    ImGuiStyle& style = ImGui::GetStyle();
    ImVec4 purple = ImVec4(0.4f, 0.0f, 0.6f, 1.0f);  
    ImVec4 darkPurple = ImVec4(0.2f, 0.0f, 0.4f, 1.0f); 

    // 👇 Цвета интерфейса
    style.Colors[ImGuiCol_WindowBg] = darkPurple;
    style.Colors[ImGuiCol_TitleBg] = purple;
    style.Colors[ImGuiCol_TitleBgActive] = purple;
    style.Colors[ImGuiCol_Tab] = purple;
    style.Colors[ImGuiCol_TabHovered] = ImVec4(0.5f, 0.1f, 0.8f, 1.0f);
    style.Colors[ImGuiCol_TabActive] = ImVec4(0.6f, 0.2f, 0.9f, 1.0f);
    style.Colors[ImGuiCol_Button] = purple;
    style.Colors[ImGuiCol_ButtonHovered] = ImVec4(0.6f, 0.2f, 0.9f, 1.0f);
    style.Colors[ImGuiCol_ButtonActive] = ImVec4(0.3f, 0.0f, 0.5f, 1.0f);
    style.Colors[ImGuiCol_FrameBg] = darkPurple;
    style.Colors[ImGuiCol_FrameBgHovered] = purple;
    style.Colors[ImGuiCol_FrameBgActive] = purple;
    style.Colors[ImGuiCol_Header] = purple;
    style.Colors[ImGuiCol_HeaderHovered] = ImVec4(0.6f, 0.2f, 0.9f, 1.0f);
    style.Colors[ImGuiCol_HeaderActive] = ImVec4(0.3f, 0.0f, 0.5f, 1.0f);
    style.Colors[ImGuiCol_CheckMark] = ImVec4(1.0f, 1.0f, 1.0f, 1.0f);  
    style.Colors[ImGuiCol_SliderGrab] = ImVec4(0.7f, 0.4f, 1.0f, 1.0f);
    style.Colors[ImGuiCol_SliderGrabActive] = ImVec4(0.9f, 0.6f, 1.0f, 1.0f);

    ImGui::SetNextWindowPos(center, ImGuiCond_Appearing, ImVec2(0.5f, 0.5f));
    if (ImGui::Begin(OBFUSCATE("OctoHook c++ version"))) {
        g_window = ImGui::GetCurrentWindow();

        if (ImGui::BeginTabBar(OBFUSCATE("Tab"))) {
            // === Tab: Main ===
            if (ImGui::BeginTabItem(OBFUSCATE("Main"))) {
                #if defined(__aarch64__)
                ImGui::Text(OBFUSCATE("Bit: 64")); 
                #else
                ImGui::Text(OBFUSCATE("Bit: 32")); 
                #endif

                ImGui::Separator();
                ImGui::Text(OBFUSCATE("Hi.")); 
                ImGui::Separator();
                ImGui::Text(OBFUSCATE("Made t.me/clientpython"));
                ImGui::Separator();

                ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.6f, 0.2f, 0.8f, 1.0f));
                ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.75f, 0.3f, 0.95f, 1.0f));
                ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(0.5f, 0.1f, 0.7f, 1.0f));

                if (ImGui::Button(OBFUSCATE("Подписаться"))) {
                    system("am start https://t.me/OctoHook");
                }
                ImGui::PopStyleColor(3); 

                ImGui::EndTabItem();
            }

            // === Tab: ESP ===
            if (ImGui::BeginTabItem(OBFUSCATE("ESP Options"))) {
                ImGui::Text(OBFUSCATE(" ESP Setttings"));
                ImGui::Checkbox(OBFUSCATE("Esp"), &espEnabled);
                ImGui::Checkbox(OBFUSCATE("Box"), &boxEnabled);
                ImGui::Checkbox(OBFUSCATE("Health Bar"), &healthBarEnabled);
                ImGui::Checkbox(OBFUSCATE("Weapon"), &weaponEnabled);
                ImGui::Checkbox(OBFUSCATE("Nick"), &nickEnabled);
                ImGui::EndTabItem();
            }

            // === Tab: Aim (включает Draw) ===
            static float aimFovSize = 100.0f;
            if (ImGui::BeginTabItem(OBFUSCATE("Aim"))) {
                ImGui::Text(OBFUSCATE(" Aim Setttings"));

                ImGui::Checkbox(OBFUSCATE("Aim"), &espEnabled);
                ImGui::Checkbox(OBFUSCATE("Silent Aim"), &boxEnabled);

                ImGui::Checkbox(OBFUSCATE("Draw"), &drawEnabled);
                if (drawEnabled) {
                    ImGui::SliderFloat(OBFUSCATE("Draw Size"), &drawSize, 1.0f, 120.0f);
                    ImGui::ColorEdit4(OBFUSCATE("Draw Color"), (float*)&drawColor);
                }

                ImGui::Checkbox(OBFUSCATE("Aim Fov"), &weaponEnabled);
                if (weaponEnabled) {
                    ImGui::SliderFloat(OBFUSCATE("Fov Size"), &aimFovSize, 10.0f, 360.0f);
                }

                ImGui::Checkbox(OBFUSCATE("Visiblity Check"), &nickEnabled);

                ImGui::EndTabItem();
            }

            // === Tab: Shaders ===
            if (ImGui::BeginTabItem(OBFUSCATE("Shaders"))) {
                for (std::string shader : shaders) {
                    ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(1, 1, 1, 1));
                    if (mineShader == shader) ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0, 1, 0, 1));
                    ImGui::PushID(shader.c_str());
                    ImGui::Text("%s", shader.c_str());
                    ImGui::SameLine();
                    if (ImGui::Button(OBFUSCATE("Set"))) {
                        mineShader = shader;
                    }
                    ImGui::Separator();
                    ImGui::PopID();
                }
                ImGui::EndTabItem();
            }

            ImGui::EndTabBar();
        }
    }

    // 🌈 RGB чамсы
    if (enableRainbow) {
        visibleColor.x = redd / 255;
        visibleColor.y = greenn / 255;
        visibleColor.z = bluee / 255;
    }
    if (enableRainbowWall) {
        inWallColor.x = redd / 255;
        inWallColor.y = greenn / 255;
        inWallColor.z = bluee / 255;
    }

    performRGBChange();
    Patches();

    // === 🎯 Отрисовка круга прицела ===
    if (drawEnabled) {
        ImDrawList* drawList = ImGui::GetBackgroundDrawList();
        ImVec2 screenCenter = ImVec2(ImGui::GetIO().DisplaySize.x * 0.5f, ImGui::GetIO().DisplaySize.y * 0.5f);
        drawList->AddCircle(screenCenter, drawSize, ImColor(drawColor), 64, 2.0f);
    }

    // === Ватермарк с FPS и временем ===
    ImDrawList* draw_list = ImGui::GetBackgroundDrawList();
    ImVec2 screenSize = ImGui::GetIO().DisplaySize;
    float fps = 1.0f / ImGui::GetIO().DeltaTime;
    time_t now = time(0);
    tm* ltm = localtime(&now);
    char datetime[64];
    strftime(datetime, sizeof(datetime), "%d.%m.%Y | %H:%M:%S", ltm);
    std::string watermark = "OctoHook |  1.0 | FPS: " + std::to_string((int)fps) + " | " + datetime;
    ImVec2 textSize = ImGui::CalcTextSize(watermark.c_str());
    ImVec2 pos = ImVec2(screenSize.x - textSize.x - 15, 10);
    ImVec4 bgColor = ImVec4(0.2f, 0.0f, 0.4f, 0.6f);
    ImVec4 textColor = ImVec4(0.9f, 0.6f, 1.0f, 1.0f);
    draw_list->AddRectFilled(ImVec2(pos.x - 6, pos.y - 4), ImVec2(pos.x + textSize.x + 6, pos.y + textSize.y + 4), ImColor(bgColor), 6.0f);
    draw_list->AddText(pos, ImColor(textColor), watermark.c_str());
}
